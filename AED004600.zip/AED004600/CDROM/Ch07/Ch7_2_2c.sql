INSERT INTO 教授 (身份證字號,教授編號,科系)
VALUES ('e12345567',2222, 'abcd');

select * from 教授