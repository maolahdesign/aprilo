USE master
GO
EXEC sp_detach_db '�Ϯ�' 