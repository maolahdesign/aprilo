USE master
GO
CREATE DATABASE �Ϯ� 
ON PRIMARY
( FILENAME = 'D:\Data\�Ϯ�.mdf' )
FOR ATTACH
