USE �аȨt�� 
GO
DECLARE @table_name char(20)
SET @table_name = '�ǥ�'
EXEC ('SELECT * FROM ' + @table_name)




