USE master
GO
CREATE DATABASE nba_dataset
GO