USE iris_dataset
GO
EXEC predict_species 'Naive Bayes';
GO