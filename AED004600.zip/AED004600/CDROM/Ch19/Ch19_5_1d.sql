USE iris_dataset
GO
SELECT TOP(10) * FROM iris_data
GO