USE master
GO
CREATE DATABASE iris_dataset
GO