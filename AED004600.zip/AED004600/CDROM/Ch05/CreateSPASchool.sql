select * from fn_helpcollations();

 

