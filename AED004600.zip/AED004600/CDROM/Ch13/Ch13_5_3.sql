DECLARE @x int = 4, @y int = 20
SET @x *= @y
SELECT @x, @y
