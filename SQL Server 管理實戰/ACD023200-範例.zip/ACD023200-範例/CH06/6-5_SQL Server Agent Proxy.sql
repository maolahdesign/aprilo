--�d�ҵ{���X6-17�G�إ�SQL�b���A�ýᤩ�̤p�v��
USE [master]
CREATE LOGIN [op] WITH PASSWORD=N'1234', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
USE [msdb]
CREATE USER [op] FOR LOGIN [op]
ALTER ROLE [SQLAgentUserRole] ADD MEMBER [op]
GO
USE [Northwind]
CREATE USER [op] FOR LOGIN [op]
ALTER ROLE [db_backupoperator] ADD MEMBER [op]
