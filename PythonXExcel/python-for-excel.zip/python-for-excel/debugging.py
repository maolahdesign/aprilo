a = 3
b = 4

c = a + b

print(c)
